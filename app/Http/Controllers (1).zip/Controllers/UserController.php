<?php



namespace App\Http\Controllers;



use Illuminate\Http\Request;
use Auth;
use App\Models\User;
use DB;

class UserController extends Controller

{

  /**

   * Create a new controller instance.

   *

   * @return void

   */

  public function __construct()
  {

    // $this->middleware('auth');
  }

  public function index()

  {
      $data = DB::table('users')->where('id','!=',Auth::user()->id)->get();

    return view('admin.users.index',compact('data'));

  }


  public function destroy($id)
    {
        //
          $user=User::find($id);
        $user->delete();

        return redirect()->route('userdata.index')
            ->with('success','Deleted successfully');
    }
}

