<?php

namespace App\Http\Controllers;
use Hash;
use App\Models\Permission;
use App\Models\Staff;
use Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class StaffController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
              $staff= DB::table('staff')->get();
      
        return view('admin.staff.index',compact('staff'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $role = db::table('roles')->get();
      
         return view('admin.staff.add',compact('role'));
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      
        //
       
    $request->validate([
            'name' => 'required',
            'email' => 'required',
            'dob' => 'required',
         'address' => 'required',
         'password' => 'required',
         'mobile' => 'required',
          'role_id' => 'required',
           
        ]);
    $data = $request->all();
    $result = new Staff;
    $result->role_id =$data['role_id'];
   $result->name = $data['name'];
   $result->email = $data['email'];
   $result->dob =$data['dob'];
   $result->mobile =$data['mobile'];
$result->address =$data['address'];

$result->password =Hash::make($data['password']);
       $result->save();
        return redirect()->route('staff.index')
            ->with('success','Created successfully.');
         
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
            $staff = Staff::find($id);
        return view('admin.staff.edit',['staff'=> $staff]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $request->validate([
            'name' => 'required',
            'email' => 'required',
            'dob' => 'required',
         'address' => 'required',
         'password' => 'required',
         'mobile' => 'required',
           'role_id' => 'required',
        ]);
        $result = Staff::find($id);
        $data = $request->all();
    $result->role_id =$data['role_id'];
  $result->name = $data['name'];
   $result->email = $data['email'];
   $result->dob =$data['dob'];
   $result->mobile =$data['mobile'];
$result->address =$data['address'];
$result->password =Hash::make($data['password']);
     $result->save();

        return redirect()->route('staff.index')
            ->with('success','Updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
          $staff=Staff::find($id);
        $staff->delete();

        return redirect()->route('staff.index')
            ->with('success','Deleted successfully');
    }
}
