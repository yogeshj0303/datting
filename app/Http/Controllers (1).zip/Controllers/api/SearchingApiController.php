<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;

use App\Models\User;
use App\Models\Favourite;
use \Cache;
use Carbon\Carbon;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Mail;
use Illuminate\Http\Request;
class SearchingApiController extends Controller
{  
     public function newest(Request $request)
    {
       
            $user = User::orderBy('id','DESC')->where('test1','=',0)->where('id','!=',$request->user_id)->get();
           foreach($user as $temp)
           {
               $temp->test2=false;
               $data =  Favourite::where('user_id',$request->user_id)->where('fav_user_id',$temp->id)->count();
               if($data > 0){
                   $temp->test2 = true;
               }
           }
            if ($user) {
                
                    return response()->json(['error' => false, 'data' => $user]);
                
            } else {
                return response()->json(['error' => true, 'data' => 'User not found!']);
            }
      
    }
     public function nearest(Request $request)
    {  

       $loop=$request->pincode;
       $loopplus=$request->pincode+25;
       $values = array();
       $data = array();
       for($i=$loop; $i<=$loopplus; $i++){
     
        $shop = User::where('pincode', $i)->where('id','!=',$request->user_id) 
        ->first();
        
        if($shop){
                 $shop->test2 = false;
                    $check =  Favourite::where('user_id',$request->user_id)->where('fav_user_id',$shop->id)->count();
               if($check > 0){
                   $shop->test2 = true;
               }
            array_push($values, $shop);
        }
   
        
       
        $mpin=$loop-($i-$loop);
        for($j=$mpin;$j>($mpin-1);$j--){
            $shop = User::where('pincode', $j)  
            ->first();
        if($shop){
            
                   $shop->test2 = false;
                    $check =  Favourite::where('user_id',$request->user_id)->where('fav_user_id',$shop->id)->count();
               if($check > 0){
                   $shop->test2 = true;
               }
        
             array_push($data, $shop);
        }
           
        }
       }
       
       $result =  array_merge($data,$values);
       
      
    //  if($shop->is_admin=="2"){
    //  echo $result;
        if ($values) {
                    return response()->json(['error' => false, 'data' => $result]);
                        } 
         else {
         return response()->json(['error' => true, 'data' => 'Users Not
         Available For this Location']);
        }
                    
    //  }
                
  
       
     
    }
      public function recentActive(Request $request)
    {
       // get user data
        $user = User::find($request->userid);

        // check online status
        if (Cache::has('user-is-online-' . $user->id))
            $status = 'Online';
        else
            $status = 'Offline';

        // check last seen
        if ($user->last_seen != null)
            $last_seen = "Active " . Carbon::parse($user->last_seen)->diffForHumans();
        else
            $last_seen = "No data";

        // response
        return response()->json([
            'status' => $status,
            'last_seen' => $last_seen,
        ]);

    }

        public function search(Request $request)
    {
       
            $user = User::where('test1','=',0)
            ->where('id','!=',$request->user_id)
            ->where('username',  'LIKE', '%'.$request->name. '%')
            ->orWhere('email',  'LIKE', '%'.$request->email. '%')
             ->orWhere('height',$request->height)
              ->orWhere('bodytype', 'LIKE', '%'.$request->bodytype. '%')
               ->orWhere('locate','LIKE', '%'.$request->locate. '%')
                ->orWhere('gender', '%'.$request->gender. '%')
                 ->orWhere('intrest',$request->intrest)
                ->orWhere('ethinicity',$request->ethnicity)
                ->orWhere('relationship', '%'.$request->relationship. '%')
                ->orWhere('children',$request->children)
                 ->orWhere('drink',$request->drink)
                 ->orWhere('education', '%'.$request->education. '%')
                 ->orWhere('smoke',$request->smoke)
                        ->get();
            foreach($user as $temp)
           {
               $temp->test2=false;
               $data =  Favourite::where('user_id',$request->user_id)->where('fav_user_id',$temp->id)->count();
               if($data > 0){
                   $temp->test2 = true;
               }
           }
            if (count($user)) {
                
                    return response()->json(['error' => false, 'data' =>$user]);
                
            } else {
                return response()->json(['error' => true, 'data' => 'User not found!']);
            }
    }
    


}
