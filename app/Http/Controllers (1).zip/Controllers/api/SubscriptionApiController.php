<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;

use App\Models\AddSubscription;
use App\Models\SubscribeUser;
use Carbon\Carbon;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Mail;
use Illuminate\Http\Request;
class SubscriptionApiController extends Controller
{  
  
    public function ShowSubscription(Request $request){
        $data =  AddSubscription::all();
      
          if ($data){
                  
                    return response()->json($data);
                
            } else {
                return response()->json(['error' => true, 'data' => 'No Data Available']);
            }
        
    }
   public function subscriptionValidity(Request $request){
        $data =  SubscribeUser::where('user_id',$request->user_id)->first();
       
            $sub =  AddSubscription::where('id',$data->sub_id)->first();
              $data->sub_id=$sub;
       $val =  $sub->validityto;
  
 if($val>now()->toDateString()){
     

                return response()->json(['error' => true, 'data' => 'Already Subscribe For this plan']);
 }else{
      return response()->json(['error' => true, 'data' => 'Subscription Expired']);
 }
    }
}
