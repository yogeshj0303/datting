@extends('admin-layout')

@section('content')





    <!-- ============================================================== -->

    <!-- Bread crumb and right sidebar toggle -->

    <!-- ============================================================== -->

    <div class="page-breadcrumb bg-white">

        <div class="row align-items-center">

            <div class="col-lg-9 col-md-4 col-sm-4 col-xs-12 pull-left">

                <h4 class="page-title">Users</h4>

            </div>


        </div>

        <!-- /.col-lg-12 -->

    </div>

    <!-- ============================================================== -->

    <!-- End Bread crumb and right sidebar toggle -->

    <!-- ============================================================== -->

    <!-- ============================================================== -->

    <!-- Container fluid  -->

    <!-- ============================================================== -->

    <div class="container-fluid">



        <div class="row">

            <div class="col-md-12 col-lg-12 col-sm-12">

                <div class="white-box">

                    <table class="table table-bordered">

                        <tr>


                            <th>S no</th>

                            <th> Name</th>

                            <th>Email</th>
                            <th>Action</th>

                        </tr>

                        @foreach ($data as $key => $user)

                            <tr>

                                <td>{{ ++$key }}</td>

                                <td>{{ $user->username }}</td>

                                <td>{{ $user->email }}</td>


  <td>

                                                                <form action="{{ route('userdata.destroy', $user->id) }}"

                                                                    method="post">

                                                                    @csrf

                                                                    @method('DELETE')



                                                                    <button onclick="return confirm('Are You sure')"

                                                                        type="submit" title="Delete" class="no-background">

                                                                        <i class="fa fa-trash text-danger"></i></button>

                                                                </form>

                                                               



                                                            </td>


                            </tr>

                        @endforeach

                    </table>



                </div>

            </div>

        </div>





    </div>

    </div>

@endsection

