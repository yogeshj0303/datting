@extends('admin-layout')

@section('content')

    <!-- ============================================================== -->

    <!-- Bread crumb and right sidebar toggle -->

    <!-- ============================================================== -->

    <div class="page-breadcrumb bg-white">

        <div class="row align-items-center">

            <div class="col-lg-9 col-md-4 col-sm-4 col-xs-12 pull-left">

                <h4 class="page-title">Add Staff</h4>

            </div>

            <div class="col-lg-3 col-sm-8 col-md-8 col-xs-12 pull-right">

                <div class="d-md-flex ">

                    <!-- <ol class="breadcrumb ms-auto">

                   <li><a href="#" class="fw-normal">Dashboard</a></li>

                   </ol> -->



                </div>

            </div>

        </div>

        <!-- /.col-lg-12 -->

    </div>

    <!-- ============================================================== -->

    <!-- End Bread crumb and right sidebar toggle -->

    <!-- ============================================================== -->

    <!-- ============================================================== -->

    <!-- Container fluid  -->

    <!-- ============================================================== -->

    <div class="container-fluid">

        <div class="row">

            <div class="col-md-12 col-lg-12 col-sm-12">

                <div class="white-box">



                    <div class="row">

                        <div class="col-md-12 stretch-card">

                            <div class="card">

                                <div class="card-body">



                                    <div class="col-md-12">



                                        @if ($errors->any())

                                            <div class="alert alert-danger">

                                                <strong>Whoops!</strong> There were some problems with your input.

                                                <ul>

                                                    @foreach ($errors->all() as $error)

                                                        <li>{{ $error }}</li>

                                                    @endforeach

                                                </ul>

                                            </div>

                                        @endif

                                        <div class="col-md-6">

                                            <form action="{{ route('staff.store') }}" method="POST">

                                                @csrf



                                                <div class="row">


                                                    <div class="col-xs-12 col-sm-12 col-md-12">

                                                        <div class="form-group">

                                                            <strong> Name:</strong>

                                                            <input type="text" name="name" placeholder="Name" id="hsnnumber"

                                                                class="form-control">

                                                        </div>

                                                    </div>
                                                    <div class="col-xs-12 col-sm-12 col-md-12">

                                                        <div class="form-group">

                                                            <strong>Email:</strong>

                                                            <input type="email" name="email" placeholder="Email" id="prodname"

                                                                class="form-control">

                                                        </div>

                                                    </div>

                                               

                                                    <div class="col-xs-12 col-sm-12 col-md-12">

                                                        <div class="form-group">

                                                            <strong>Mobile No:</strong>

                                                            <input type="text" style="text-align: left" name="mobile" placeholder="Mobile No" id="up" class="form-control">

                                                        </div>

                                                    </div>
                                                 <div class="col-xs-12 col-sm-12 col-md-12">
                                                  <div class="form-group">

                                                            <strong>Date Of Birth</strong>

                                                            <input type="date" style="text-align: left" name="dob" id="up" class="form-control">

                                                        </div>

                                                    </div>
                                                 <div class="form-group">

                                                            <strong>Address:</strong>
                                                        <textarea id="w3review" placeholder="Address"  name="address" class="form-control" rows="4" cols="50"></textarea>
                                                           

                                                        </div>

                                                    </div>

  
                                                    
                                                 <div class="col-xs-12 col-sm-12 col-md-12">
                                                        <div class="form-group">

                                                            <strong>Passoword:</strong>

                                                            <input type="password" style="text-align: left" name="password" placeholder="Password" id="up" class="form-control">

                                                        </div>

                                                    </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12">

                                                        <div class="form-group">

                                                            <strong>Assign Role:</strong>

                                                            <select name="role_id"  class="form-control rounded-0" id="qty" required="">
                                                                <option value="">--Select Role Name--</option>
                                                               @foreach( $role as $row )
                                                                <option value="{{ $row->id }}">{{ $row->role_name }}</option>
                                                                  @endforeach


                                                          </select>

                                                        </div>

                                                    </div>


                                                    <div class="col-xs-12 col-sm-12 col-md-12">

                                                        <br> <br>

                                                        <button type="submit" class="btn btn-success">Add Staff</button>

                                                    </div>

                                                </div>



                                            </form>

                                        </div>



                                    </div>

                                </div>

                            </div>

                        </div>

                        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

                        <script type="text/javascript">

                            $(document).on('change', '#qty', function() {



                                var qty =  document.getElementById('qty').value;

                                var uprice =  document.getElementById('up').value;

                                document.getElementById('tot').value = parseFloat(qty * uprice).toFixed(2);



                            });



                            $(document).on('change', '#up', function() {



                                var qty =  document.getElementById('qty').value;

                                var uprice =  document.getElementById('up').value;

                                document.getElementById('tot').value = parseFloat(qty * uprice).toFixed(2);

                                document.getElementById('up').value = parseFloat(document.getElementById('up').value).toFixed(2);



                            });

                            $(document).on('change', '#gst', function() {



                               var qty = document.getElementById('qty').value;

                                var uprice = document.getElementById('up').value;

                                var gst = document.getElementById('gst').value;

                                var originalprice=parseFloat(qty*uprice);

                                alert(originalprice);

                                var amount= (originalprice * parseFloat(gst))/100;

                                var netprice= parseFloat(originalprice + amount).toFixed(2);

                                document.getElementById('tot').value = netprice;



                            });





                        </script>

                    @endsection

