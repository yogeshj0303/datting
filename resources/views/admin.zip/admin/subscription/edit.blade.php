@extends('admin-layout')

@section('content')

    <!-- ============================================================== -->

    <!-- Bread crumb and right sidebar toggle -->

    <!-- ============================================================== -->

    <div class="page-breadcrumb bg-white">

        <div class="row align-items-center">

            <div class="col-lg-9 col-md-4 col-sm-4 col-xs-12 pull-left">

                <h4 class="page-title">Edit Subscription</h4>

            </div>

            <div class="col-lg-3 col-sm-8 col-md-8 col-xs-12 pull-right">

                <div class="d-md-flex ">

                    <!-- <ol class="breadcrumb ms-auto">

                   <li><a href="#" class="fw-normal">Dashboard</a></li>

                   </ol> -->



                </div>

            </div>

        </div>

        <!-- /.col-lg-12 -->

    </div>

    <!-- ============================================================== -->

    <!-- End Bread crumb and right sidebar toggle -->

    <!-- ============================================================== -->

    <!-- ============================================================== -->

    <!-- Container fluid  -->

    <!-- ============================================================== -->

    <div class="container-fluid">

        <div class="row">

            <div class="col-md-12 col-lg-12 col-sm-12">

                <div class="white-box">



                    <div class="row">

                        <div class="col-md-12 stretch-card">

                            <div class="card">

                                <div class="card-body">



                                    <div class="col-md-12">

                                        @if ($errors->any())

                                            <div class="alert alert-danger">

                                                <strong>Whoops!</strong> There were some problems with your input.

                                                <ul>

                                                    @foreach ($errors->all() as $error)

                                                        <li>{{ $error }}</li>

                                                    @endforeach

                                                </ul>

                                            </div>

                                        @endif

                                        <div class="col-md-6">

                                            <form action="{{ route('addsubs.update', $subscription->id) }}" method="POST">

                                                @csrf
                                                @method('PUT')
                                                <div class="form-group">

                                                    <label for="">Plan Name</label>

                                                    <input type="text" class="form-control" name="plan" id="unitname"
                                                        placeholder="Price Name" value={{$subscription->plan}}>
                                                    <span class="text-danger">@error('unitname') {{ $message }}
                                                        @enderror</span>

                                                </div>
                                        <div class="form-group">

                                                    <label for="">Price</label>

                                                    <input type="text" class="form-control" name="price" id="unitname"
                                                        placeholder="Price" value={{$subscription->price}}>
                                                    <span class="text-danger">@error('unitname') {{ $message }}
                                                        @enderror</span>

                                                </div>

 <div class="form-group">

                                                    <label for="">Validity From</label>

                                                    <input type="date" class="form-control" name="validityfrom" id="unitname"
                                                        placeholder="Validity" value={{$subscription->validityfrom}}>
                                                    <span class="text-danger">@error('unitname') {{ $message }}
                                                        @enderror</span>

                                                </div>
                                                 <div class="form-group">

                                                    <label for="">Validity To</label>

                                                    <input type="date" class="form-control" name="validityto" id="unitname"
                                                        placeholder="Validity" value={{$subscription->validityto}}>
                                                    <span class="text-danger">@error('unitname') {{ $message }}
                                                        @enderror</span>

                                                </div>
                                     <div class="form-group">
                                             <label for="">Plan Description</label>
                                <textarea id="w3review" value="{{$subscription->des}}" name="des" class="form-control" rows="4" cols="50"></textarea>
                                                    <span class="text-danger">@error('unitname') {{ $message }}
                                                        @enderror</span>

                                                </div>

                                                <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

                                                <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.1/moment.min.js"></script>

                                                <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>

                                                <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.7.14/js/bootstrap-datetimepicker.min.js">

                                                </script>





                                                <br>

                                                <div class="col-xs-12 col-sm-12 col-md-12">

                                                    <br><br>

                                                    <button type="submit" class="btn btn-success">Update</button>

                                                    </a>

                                                </div>



                                        </form>

                                        </div>

                                    </div>

                                </div>

                            </div>

                            <script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

                              <script>



$(document).on('change', '.amtclass', function() {

            this.value = parseFloat(this.value).toFixed(2);

        });

                                </script>

                        @endsection







