@extends('frontend.layout.main-after')
@section('main2.container')


    {{-- ===========================================
                    PAGE HEADER
    =========================================== --}}
    <section class="page-header-section style-1 breadcrumb-section">
        <div class="container">
            <div class="page-header-content">
                <div class="page-header-inner">
                    <div class="page-title">
                        <h2>Interest</h2>
                    </div>
                    <ol class="breadcrumb">
                        <li><a href="index.html">Home</a></li>
                        <li class="active">Interest</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    {{-- ===========================================
                    INTEREST PAGE
    =========================================== --}}
    <section class="container-fluid interest-section">
        {{--  <div class="container">  --}}
            <div class="tab-button">
                <button class="tablink flex-fill" onclick="openPage('viewedMe', this, '#b30101')" id="defaultOpen">Viewed Me</button>
                <button class="tablink flex-fill" onclick="openPage('favourited', this, '#b30101')">Favourited Me</button>
                <button class="tablink flex-fill" onclick="openPage('myfavourites', this, '#b30101')">My Favourites</button>
            </div>

            {{--  ========= Viewed Me =========  --}}
            <div id="viewedMe" class="tabcontent">
                <div class="row profile-grid">
                    @foreach($user as $temp)
                    <div class="col-lg-3 col-md-4 col-sm-6 profile-item">
                        <div class="profile-card">
                            <div class="profile-img">
                                <a href="other-profile">
                                    <img src="{{ asset('uploads/image/'  . $temp->image) }}" alt="..." class="w-100 h-100">
                                </a>
                                <span class="profile-badge">
                                    <img src="{{ asset('uploads/image/'  . $temp->image) }}" alt="..."  data-bs-toggle="tooltip" title="Diamond Member">
                                </span>
                            </div>
                            <div class="profile-detail">
                                <div class="profile-info">
                                    <div class="name d-flex">
                                        <div class="profile-name">
                                            <h6 class="mb-0 text-truncate">{{$temp->username}}</h6>
                                        </div>
                                        <div class="tick">
                                            {{--  <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>  --}}
                                            <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>
                                        </div>
                                    </div>
                                    <p class="mb-0">{{$temp->locate}}</p>
                                </div>
                                <div class="d-flex align-items-center">
                                    <button class="like-btn"> <i class="fa-regular fa-heart text-theme"></i> </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                    <!--<div class="col-lg-3 col-md-4 col-sm-6 profile-item">-->
                    <!--    <div class="profile-card">-->
                    <!--        <div class="profile-img">-->
                    <!--            <a href="other-profile">-->
                    <!--                <img src="{{ asset('assets/images/profile/single/07.jpg') }}" alt="..." class="w-100 h-100">-->
                    <!--            </a>-->
                    <!--            <span class="profile-badge">-->
                    <!--                <img src="{{ asset('assets/images/icons/platinum.png') }}" alt="..."  data-bs-toggle="tooltip" title="Platinum Member">-->
                    <!--            </span>-->
                    <!--        </div>-->
                    <!--        <div class="profile-detail">-->
                    <!--            <div class="profile-info">-->
                    <!--                <div class="name d-flex">-->
                    <!--                    <div class="profile-name">-->
                    <!--                        <h6 class="mb-0 text-truncate">Johnny Wilson</h6>-->
                    <!--                    </div>-->
                    <!--                    <div class="tick">-->
                    <!--                        {{--  <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>  --}}-->
                    <!--                        {{--  <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>  --}}-->
                    <!--                    </div>-->
                    <!--                </div>-->
                    <!--                <p class="mb-0">Canada</p>-->
                    <!--            </div>-->
                    <!--            <div class="d-flex align-items-center">-->
                    <!--                <button class="like-btn"> <i class="fa-regular fa-heart text-theme"></i> </button>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <!--<div class="col-lg-3 col-md-4 col-sm-6 profile-item">-->
                    <!--    <div class="profile-card">-->
                    <!--        <div class="profile-img">-->
                    <!--            <a href="other-profile">-->
                    <!--                <img src="{{ asset('assets/images/profile/single/04.jpg') }}" alt="..." class="w-100 h-100">-->
                    <!--            </a>-->
                    <!--            <span class="profile-badge">-->
                    <!--                <img src="{{ asset('assets/images/icons/gold.png') }}" alt="..."  data-bs-toggle="tooltip" title="Gold Member">-->
                    <!--            </span>-->
                    <!--        </div>-->
                    <!--        <div class="profile-detail">-->
                    <!--            <div class="profile-info">-->
                    <!--                <div class="name d-flex">-->
                    <!--                    <div class="profile-name">-->
                    <!--                        <h6 class="mb-0 text-truncate">Johnny Wilson</h6>-->
                    <!--                    </div>-->
                    <!--                    <div class="tick">-->
                    <!--                        <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>-->
                    <!--                        <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>-->
                    <!--                    </div>-->
                    <!--                </div>-->
                    <!--                <p class="mb-0">Canada</p>-->
                    <!--            </div>-->
                    <!--            <div class="d-flex align-items-center">-->
                    <!--                <button class="like-btn"> <i class="fa-regular fa-heart text-theme"></i> </button>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <!--<div class="col-lg-3 col-md-4 col-sm-6 profile-item">-->
                    <!--    <div class="profile-card">-->
                    <!--        <div class="profile-img">-->
                    <!--            <a href="other-profile">-->
                    <!--                <img src="{{ asset('assets/images/profile/single/02.jpg') }}" alt="..." class="w-100 h-100">-->
                    <!--            </a>-->
                    <!--            <span class="profile-badge">-->
                    <!--                <img src="{{ asset('assets/images/icons/platinum.png') }}" alt="..."  data-bs-toggle="tooltip" title="Platinum Member">-->
                    <!--            </span>-->
                    <!--        </div>-->
                    <!--        <div class="profile-detail">-->
                    <!--            <div class="profile-info">-->
                    <!--                <div class="name d-flex">-->
                    <!--                    <div class="profile-name">-->
                    <!--                        <h6 class="mb-0 text-truncate">Johnny Wilson</h6>-->
                    <!--                    </div>-->
                    <!--                    <div class="tick">-->
                    <!--                        {{--  <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>  --}}-->
                    <!--                        <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>-->
                    <!--                    </div>-->
                    <!--                </div>-->
                    <!--                <p class="mb-0">Canada</p>-->
                    <!--            </div>-->
                    <!--            <div class="d-flex align-items-center">-->
                    <!--                <button class="like-btn"> <i class="fa-regular fa-heart text-theme"></i> </button>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <!--<div class="col-lg-3 col-md-4 col-sm-6 profile-item">-->
                    <!--    <div class="profile-card">-->
                    <!--        <div class="profile-img">-->
                    <!--            <a href="other-profile">-->
                    <!--                <img src="{{ asset('assets/images/profile/single/06.jpg') }}" alt="..." class="w-100 h-100">-->
                    <!--            </a>-->
                    <!--            <span class="profile-badge">-->
                    <!--                <img src="{{ asset('assets/images/icons/diamond.png') }}" alt="..."  data-bs-toggle="tooltip" title="Diamond Member">-->
                    <!--            </span>-->
                    <!--        </div>-->
                    <!--        <div class="profile-detail">-->
                    <!--            <div class="profile-info">-->
                    <!--                <div class="name d-flex">-->
                    <!--                    <div class="profile-name">-->
                    <!--                        <h6 class="mb-0 text-truncate">Johnny Wilson</h6>-->
                    <!--                    </div>-->
                    <!--                    <div class="tick">-->
                    <!--                        <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>-->
                    <!--                        <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>-->
                    <!--                    </div>-->
                    <!--                </div>-->
                    <!--                <p class="mb-0">Canada</p>-->
                    <!--            </div>-->
                    <!--            <div class="d-flex align-items-center">-->
                    <!--                <button class="like-btn"> <i class="fa-regular fa-heart text-theme"></i> </button>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <!--<div class="col-lg-3 col-md-4 col-sm-6 profile-item">-->
                    <!--    <div class="profile-card">-->
                    <!--        <div class="profile-img">-->
                    <!--            <a href="other-profile">-->
                    <!--                <img src="{{ asset('assets/images/profile/single/07.jpg') }}" alt="..." class="w-100 h-100">-->
                    <!--            </a>-->
                    <!--            <span class="profile-badge">-->
                    <!--                <img src="{{ asset('assets/images/icons/platinum.png') }}" alt="..."  data-bs-toggle="tooltip" title="Platinum Member">-->
                    <!--            </span>-->
                    <!--        </div>-->
                    <!--        <div class="profile-detail">-->
                    <!--            <div class="profile-info">-->
                    <!--                <div class="name d-flex">-->
                    <!--                    <div class="profile-name">-->
                    <!--                        <h6 class="mb-0 text-truncate">Johnny Wilson</h6>-->
                    <!--                    </div>-->
                    <!--                    <div class="tick">-->
                    <!--                        {{--  <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>  --}}-->
                    <!--                        {{--  <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>  --}}-->
                    <!--                    </div>-->
                    <!--                </div>-->
                    <!--                <p class="mb-0">Canada</p>-->
                    <!--            </div>-->
                    <!--            <div class="d-flex align-items-center">-->
                    <!--                <button class="like-btn"> <i class="fa-regular fa-heart text-theme"></i> </button>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <!--<div class="col-lg-3 col-md-4 col-sm-6 profile-item">-->
                    <!--    <div class="profile-card">-->
                    <!--        <div class="profile-img">-->
                    <!--            <a href="other-profile">-->
                    <!--                <img src="{{ asset('assets/images/profile/single/03.jpg') }}" alt="..." class="w-100 h-100">-->
                    <!--            </a>-->
                    <!--            <span class="profile-badge">-->
                    <!--                {{--  <img src="{{ asset('assets/images/icons/gold.png') }}" alt="..."  data-bs-toggle="tooltip" title="Gold Member">  --}}-->
                    <!--            </span>-->
                    <!--        </div>-->
                    <!--        <div class="profile-detail">-->
                    <!--            <div class="profile-info">-->
                    <!--                <div class="name d-flex">-->
                    <!--                    <div class="profile-name">-->
                    <!--                        <h6 class="mb-0 text-truncate">Johnny Wilson</h6>-->
                    <!--                    </div>-->
                    <!--                    <div class="tick">-->
                    <!--                        {{--  <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>  --}}-->
                    <!--                        {{--  <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>  --}}-->
                    <!--                    </div>-->
                    <!--                </div>-->
                    <!--                <p class="mb-0">Canada</p>-->
                    <!--            </div>-->
                    <!--            <div class="d-flex align-items-center">-->
                    <!--                <button class="like-btn"> <i class="fa-regular fa-heart text-theme"></i> </button>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <!--<div class="col-lg-3 col-md-4 col-sm-6 profile-item">-->
                    <!--    <div class="profile-card">-->
                    <!--        <div class="profile-img">-->
                    <!--            <a href="other-profile">-->
                    <!--                <img src="{{ asset('assets/images/profile/single/02.jpg') }}" alt="..." class="w-100 h-100">-->
                    <!--            </a>-->
                    <!--            <span class="profile-badge">-->
                    <!--                <img src="{{ asset('assets/images/icons/platinum.png') }}" alt="..."  data-bs-toggle="tooltip" title="Platinum Member">-->
                    <!--            </span>-->
                    <!--        </div>-->
                    <!--        <div class="profile-detail">-->
                    <!--            <div class="profile-info">-->
                    <!--                <div class="name d-flex">-->
                    <!--                    <div class="profile-name">-->
                    <!--                        <h6 class="mb-0 text-truncate">Johnny Wilson</h6>-->
                    <!--                    </div>-->
                    <!--                    <div class="tick">-->
                    <!--                        <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>-->
                    <!--                        <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>-->
                    <!--                    </div>-->
                    <!--                </div>-->
                    <!--                <p class="mb-0">Canada</p>-->
                    <!--            </div>-->
                    <!--            <div class="d-flex align-items-center">-->
                    <!--                <button class="like-btn"> <i class="fa-regular fa-heart text-theme"></i> </button>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                </div>
            </div>

            {{--  ========= Favourited Me =========  --}}
            <div id="favourited" class="tabcontent">
                <div class="row profile-grid">
                    <div class="col-lg-3 col-md-4 col-sm-6 profile-item">
                        <div class="profile-card">
                            <div class="profile-img">
                                <a href="other-profile">
                                    <img src="{{ asset('assets/images/profile/single/04.jpg') }}" alt="..." class="w-100 h-100">
                                </a>
                                <span class="profile-badge">
                                    <img src="{{ asset('assets/images/icons/gold.png') }}" alt="..."  data-bs-toggle="tooltip" title="Gold Member">
                                </span>
                            </div>
                            <div class="profile-detail">
                                <div class="profile-info">
                                    <div class="name d-flex">
                                        <div class="profile-name">
                                            <h6 class="mb-0 text-truncate">Johnny Wilson</h6>
                                        </div>
                                        <div class="tick">
                                            <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>
                                            <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>
                                        </div>
                                    </div>
                                    <p class="mb-0">Canada</p>
                                </div>
                                <div class="d-flex align-items-center">
                                    <button class="like-btn"> <i class="fa-regular fa-heart text-theme"></i> </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6 profile-item">
                        <div class="profile-card">
                            <div class="profile-img">
                                <a href="other-profile">
                                    <img src="{{ asset('assets/images/profile/single/07.jpg') }}" alt="..." class="w-100 h-100">
                                </a>
                                <span class="profile-badge">
                                    <img src="{{ asset('assets/images/icons/diamond.png') }}" alt="..."  data-bs-toggle="tooltip" title="Diamond Member">
                                </span>
                            </div>
                            <div class="profile-detail">
                                <div class="profile-info">
                                    <div class="name d-flex">
                                        <div class="profile-name">
                                            <h6 class="mb-0 text-truncate">Johnny Wilson</h6>
                                        </div>
                                        <div class="tick">
                                            {{--  <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>  --}}
                                            {{--  <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>  --}}
                                        </div>
                                    </div>
                                    <p class="mb-0">Canada</p>
                                </div>
                                <div class="d-flex align-items-center">
                                    <button class="like-btn"> <i class="fa-regular fa-heart text-theme"></i> </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6 profile-item">
                        <div class="profile-card">
                            <div class="profile-img">
                                <a href="other-profile">
                                    <img src="{{ asset('assets/images/profile/single/02.jpg') }}" alt="..." class="w-100 h-100">
                                </a>
                                <span class="profile-badge">
                                    <img src="{{ asset('assets/images/icons/gold.png') }}" alt="..."  data-bs-toggle="tooltip" title="Gold Member">
                                </span>
                            </div>
                            <div class="profile-detail">
                                <div class="profile-info">
                                    <div class="name d-flex">
                                        <div class="profile-name">
                                            <h6 class="mb-0 text-truncate">Johnny Wilson</h6>
                                        </div>
                                        <div class="tick">
                                            {{--  <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>  --}}
                                            <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>
                                        </div>
                                    </div>
                                    <p class="mb-0">Canada</p>
                                </div>
                                <div class="d-flex align-items-center">
                                    <button class="like-btn"> <i class="fa-regular fa-heart text-theme"></i> </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6 profile-item">
                        <div class="profile-card">
                            <div class="profile-img">
                                <a href="other-profile">
                                    <img src="{{ asset('assets/images/profile/single/05.jpg') }}" alt="..." class="w-100 h-100">
                                </a>
                                <span class="profile-badge">
                                    <img src="{{ asset('assets/images/icons/platinum.png') }}" alt="..."  data-bs-toggle="tooltip" title="Platinum Member">
                                </span>
                            </div>
                            <div class="profile-detail">
                                <div class="profile-info">
                                    <div class="name d-flex">
                                        <div class="profile-name">
                                            <h6 class="mb-0 text-truncate">Johnny Wilson</h6>
                                        </div>
                                        <div class="tick">
                                            <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>
                                            {{--  <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>  --}}
                                        </div>
                                    </div>
                                    <p class="mb-0">Canada</p>
                                </div>
                                <div class="d-flex align-items-center">
                                    <button class="like-btn"> <i class="fa-regular fa-heart text-theme"></i> </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6 profile-item">
                        <div class="profile-card">
                            <div class="profile-img">
                                <a href="other-profile">
                                    <img src="{{ asset('assets/images/profile/single/08.jpg') }}" alt="..." class="w-100 h-100">
                                </a>
                                <span class="profile-badge">
                                    <img src="{{ asset('assets/images/icons/gold.png') }}" alt="..."  data-bs-toggle="tooltip" title="Gold Member">
                                </span>
                            </div>
                            <div class="profile-detail">
                                <div class="profile-info">
                                    <div class="name d-flex">
                                        <div class="profile-name">
                                            <h6 class="mb-0 text-truncate">Johnny Wilson</h6>
                                        </div>
                                        <div class="tick">
                                            {{--  <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>  --}}
                                            {{--  <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>  --}}
                                        </div>
                                    </div>
                                    <p class="mb-0">Canada</p>
                                </div>
                                <div class="d-flex align-items-center">
                                    <button class="like-btn"> <i class="fa-regular fa-heart text-theme"></i> </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6 profile-item">
                        <div class="profile-card">
                            <div class="profile-img">
                                <a href="other-profile">
                                    <img src="{{ asset('assets/images/profile/single/03.jpg') }}" alt="..." class="w-100 h-100">
                                </a>
                                <span class="profile-badge">
                                    <img src="{{ asset('assets/images/icons/gold.png') }}" alt="..."  data-bs-toggle="tooltip" title="Gold Member">
                                </span>
                            </div>
                            <div class="profile-detail">
                                <div class="profile-info">
                                    <div class="name d-flex">
                                        <div class="profile-name">
                                            <h6 class="mb-0 text-truncate">Johnny Wilson</h6>
                                        </div>
                                        <div class="tick">
                                            {{--  <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>  --}}
                                            <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>
                                        </div>
                                    </div>
                                    <p class="mb-0">Canada</p>
                                </div>
                                <div class="d-flex align-items-center">
                                    <button class="like-btn"> <i class="fa-regular fa-heart text-theme"></i> </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {{--  ========= My Favourites =========  --}}
            <div id="myfavourites" class="tabcontent">
                <div class="row profile-grid">
                    <?php
                      $data =  session()->get('userid');
                    $user = DB::table('favourites')->orderBy('id', "desc")->where('user_id','=' ,'$data')->get();
                      
                    foreach($user as $temp){
                        
                    
                        $data = Client::orderBy('id',"desc")->where('id',$temp->fav_user_id)->first();
                         if($data){
                               $data->test2 = false;
                                $check =  Favourite::where('user_id',$request->user_id)->where('fav_user_id',$data->id)->count();
                           if($check > 0){
                               $data->test2 = true;
                           }
                           }
                       $temp->fav_user_id=$data;
                    }
                  
                    ?>
                    
                    @foreach($user as $temp)
                    <div class="col-lg-3 col-md-4 col-sm-6 profile-item">
                        <div class="profile-card">
                            <div class="profile-img">
                                <a href="other-profile">
                                    <img src="{{ asset('uploads/image/'  . $temp->image) }}" alt="..." class="w-100 h-100">
                                </a>
                                <span class="profile-badge">
                                    <img src="{{ asset('assets/images/icons/diamond.png') }}" alt="..."  data-bs-toggle="tooltip" title="Diamond Member">
                                </span>
                            </div>
                            <div class="profile-detail">
                                <div class="profile-info">
                                    <div class="name d-flex">
                                        <div class="profile-name">
                                            <h6 class="mb-0 text-truncate">{{$temp->username}}</h6>
                                        </div>
                                        <div class="tick">
                                            {{--  <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>  --}}
                                            <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>
                                        </div>
                                    </div>
                                    <p class="mb-0">{{$temp->locate}}</p>
                                </div>
                                <div class="d-flex align-items-center">
                                    <button class="like-btn"> <i class="fa-solid fa-heart text-theme"></i> </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                    <!--<div class="col-lg-3 col-md-4 col-sm-6 profile-item">-->
                    <!--    <div class="profile-card">-->
                    <!--        <div class="profile-img">-->
                    <!--            <a href="other-profile">-->
                    <!--                <img src="{{ asset('assets/images/profile/single/07.jpg') }}" alt="..." class="w-100 h-100">-->
                    <!--            </a>-->
                    <!--            <span class="profile-badge">-->
                    <!--                <img src="{{ asset('assets/images/icons/platinum.png') }}" alt="..."  data-bs-toggle="tooltip" title="Platinum Member">-->
                    <!--            </span>-->
                    <!--        </div>-->
                    <!--        <div class="profile-detail">-->
                    <!--            <div class="profile-info">-->
                    <!--                <div class="name d-flex">-->
                    <!--                    <div class="profile-name">-->
                    <!--                        <h6 class="mb-0 text-truncate">Johnny Wilson</h6>-->
                    <!--                    </div>-->
                    <!--                    <div class="tick">-->
                    <!--                        {{--  <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>  --}}-->
                    <!--                        {{--  <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>  --}}-->
                    <!--                    </div>-->
                    <!--                </div>-->
                    <!--                <p class="mb-0">Canada</p>-->
                    <!--            </div>-->
                    <!--            <div class="d-flex align-items-center">-->
                    <!--                <button class="like-btn"> <i class="fa-solid fa-heart text-theme"></i> </button>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <!--<div class="col-lg-3 col-md-4 col-sm-6 profile-item">-->
                    <!--    <div class="profile-card">-->
                    <!--        <div class="profile-img">-->
                    <!--            <a href="other-profile">-->
                    <!--                <img src="{{ asset('assets/images/profile/single/04.jpg') }}" alt="..." class="w-100 h-100">-->
                    <!--            </a>-->
                    <!--            <span class="profile-badge">-->
                    <!--                {{--  <img src="{{ asset('assets/images/icons/gold.png') }}" alt="..."  data-bs-toggle="tooltip" title="Gold Member">  --}}-->
                    <!--            </span>-->
                    <!--        </div>-->
                    <!--        <div class="profile-detail">-->
                    <!--            <div class="profile-info">-->
                    <!--                <div class="name d-flex">-->
                    <!--                    <div class="profile-name">-->
                    <!--                        <h6 class="mb-0 text-truncate">Johnny Wilson</h6>-->
                    <!--                    </div>-->
                    <!--                    <div class="tick">-->
                    <!--                        {{--  <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>  --}}-->
                    <!--                        <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>-->
                    <!--                    </div>-->
                    <!--                </div>-->
                    <!--                <p class="mb-0">Canada</p>-->
                    <!--            </div>-->
                    <!--            <div class="d-flex align-items-center">-->
                    <!--                <button class="like-btn"> <i class="fa-solid fa-heart text-theme"></i> </button>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <!--<div class="col-lg-3 col-md-4 col-sm-6 profile-item">-->
                    <!--    <div class="profile-card">-->
                    <!--        <div class="profile-img">-->
                    <!--            <a href="other-profile">-->
                    <!--                <img src="{{ asset('assets/images/profile/single/02.jpg') }}" alt="..." class="w-100 h-100">-->
                    <!--            </a>-->
                    <!--            <span class="profile-badge">-->
                    <!--                <img src="{{ asset('assets/images/icons/diamond.png') }}" alt="..."  data-bs-toggle="tooltip" title="Diamond Member">-->
                    <!--            </span>-->
                    <!--        </div>-->
                    <!--        <div class="profile-detail">-->
                    <!--            <div class="profile-info">-->
                    <!--                <div class="name d-flex">-->
                    <!--                    <div class="profile-name">-->
                    <!--                        <h6 class="mb-0 text-truncate">Johnny Wilson</h6>-->
                    <!--                    </div>-->
                    <!--                    <div class="tick">-->
                    <!--                        <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>-->
                    <!--                        {{--  <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>  --}}-->
                    <!--                    </div>-->
                    <!--                </div>-->
                    <!--                <p class="mb-0">Canada</p>-->
                    <!--            </div>-->
                    <!--            <div class="d-flex align-items-center">-->
                    <!--                <button class="like-btn"> <i class="fa-solid fa-heart text-theme"></i> </button>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <!--<div class="col-lg-3 col-md-4 col-sm-6 profile-item">-->
                    <!--    <div class="profile-card">-->
                    <!--        <div class="profile-img">-->
                    <!--            <a href="other-profile">-->
                    <!--                <img src="{{ asset('assets/images/profile/single/03.jpg') }}" alt="..." class="w-100 h-100">-->
                    <!--            </a>-->
                    <!--            <span class="profile-badge">-->
                    <!--                <img src="{{ asset('assets/images/icons/platinum.png') }}" alt="..."  data-bs-toggle="tooltip" title="Platinum Member">-->
                    <!--            </span>-->
                    <!--        </div>-->
                    <!--        <div class="profile-detail">-->
                    <!--            <div class="profile-info">-->
                    <!--                <div class="name d-flex">-->
                    <!--                    <div class="profile-name">-->
                    <!--                        <h6 class="mb-0 text-truncate">Johnny Wilson</h6>-->
                    <!--                    </div>-->
                    <!--                    <div class="tick">-->
                    <!--                        <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>-->
                    <!--                        <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>-->
                    <!--                    </div>-->
                    <!--                </div>-->
                    <!--                <p class="mb-0">Canada</p>-->
                    <!--            </div>-->
                    <!--            <div class="d-flex align-items-center">-->
                    <!--                <button class="like-btn"> <i class="fa-solid fa-heart text-theme"></i> </button>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <!--<div class="col-lg-3 col-md-4 col-sm-6 profile-item">-->
                    <!--    <div class="profile-card">-->
                    <!--        <div class="profile-img">-->
                    <!--            <a href="other-profile">-->
                    <!--                <img src="{{ asset('assets/images/profile/single/07.jpg') }}" alt="..." class="w-100 h-100">-->
                    <!--            </a>-->
                    <!--            <span class="profile-badge">-->
                    <!--                <img src="{{ asset('assets/images/icons/gold.png') }}" alt="..."  data-bs-toggle="tooltip" title="Gold Member">-->
                    <!--            </span>-->
                    <!--        </div>-->
                    <!--        <div class="profile-detail">-->
                    <!--            <div class="profile-info">-->
                    <!--                <div class="name d-flex">-->
                    <!--                    <div class="profile-name">-->
                    <!--                        <h6 class="mb-0 text-truncate">Johnny Wilson</h6>-->
                    <!--                    </div>-->
                    <!--                    <div class="tick">-->
                    <!--                        {{--  <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>  --}}-->
                    <!--                        {{--  <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>  --}}-->
                    <!--                    </div>-->
                    <!--                </div>-->
                    <!--                <p class="mb-0">Canada</p>-->
                    <!--            </div>-->
                    <!--            <div class="d-flex align-items-center">-->
                    <!--                <button class="like-btn"> <i class="fa-solid fa-heart text-theme"></i> </button>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <!--<div class="col-lg-3 col-md-4 col-sm-6 profile-item">-->
                    <!--    <div class="profile-card">-->
                    <!--        <div class="profile-img">-->
                    <!--            <a href="other-profile">-->
                    <!--                <img src="{{ asset('assets/images/profile/single/04.jpg') }}" alt="..." class="w-100 h-100">-->
                    <!--            </a>-->
                    <!--            <span class="profile-badge">-->
                    <!--                <img src="{{ asset('assets/images/icons/diamond.png') }}" alt="..."  data-bs-toggle="tooltip" title="Diamond Member">-->
                    <!--            </span>-->
                    <!--        </div>-->
                    <!--        <div class="profile-detail">-->
                    <!--            <div class="profile-info">-->
                    <!--                <div class="name d-flex">-->
                    <!--                    <div class="profile-name">-->
                    <!--                        <h6 class="mb-0 text-truncate">Johnny Wilson</h6>-->
                    <!--                    </div>-->
                    <!--                    <div class="tick">-->
                    <!--                        <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>-->
                    <!--                        {{--  <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>  --}}-->
                    <!--                    </div>-->
                    <!--                </div>-->
                    <!--                <p class="mb-0">Canada</p>-->
                    <!--            </div>-->
                    <!--            <div class="d-flex align-items-center">-->
                    <!--                <button class="like-btn"> <i class="fa-solid fa-heart text-theme"></i> </button>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <!--<div class="col-lg-3 col-md-4 col-sm-6 profile-item">-->
                    <!--    <div class="profile-card">-->
                    <!--        <div class="profile-img">-->
                    <!--            <a href="other-profile">-->
                    <!--                <img src="{{ asset('assets/images/profile/single/02.jpg') }}" alt="..." class="w-100 h-100">-->
                    <!--            </a>-->
                    <!--            <span class="profile-badge">-->
                    <!--                {{--  <img src="{{ asset('assets/images/icons/gold.png') }}" alt="..."  data-bs-toggle="tooltip" title="Gold Member">  --}}-->
                    <!--            </span>-->
                    <!--        </div>-->
                    <!--        <div class="profile-detail">-->
                    <!--            <div class="profile-info">-->
                    <!--                <div class="name d-flex">-->
                    <!--                    <div class="profile-name">-->
                    <!--                        <h6 class="mb-0 text-truncate">Johnny Wilson</h6>-->
                    <!--                    </div>-->
                    <!--                    <div class="tick">-->
                    <!--                        {{--  <i class="fa-solid fa-circle-check text-primary"  data-bs-toggle="tooltip" title="Verified"></i>  --}}-->
                    <!--                        <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>-->
                    <!--                    </div>-->
                    <!--                </div>-->
                    <!--                <p class="mb-0">Canada</p>-->
                    <!--            </div>-->
                    <!--            <div class="d-flex align-items-center">-->
                    <!--                <button class="like-btn"> <i class="fa-solid fa-heart text-theme"></i> </button>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                </div>
            </div>

        {{--  </div>  --}}
    </section>


@endsection
