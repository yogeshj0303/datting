@include('frontend.layout.head-after')
@yield('main2.container')
@include('frontend.layout.footer')
