@include('frontend.layout.header')
@yield('main.container')
@include('frontend.layout.footer')