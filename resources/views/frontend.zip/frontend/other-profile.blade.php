@extends('frontend.layout.main-after')
@section('main2.container')


    {{-- ===========================================
                    PAGE HEADER
    =========================================== --}}
    <section class="page-header-section style-1 breadcrumb-section">
        <div class="container">
            <div class="page-header-content">
                <div class="page-header-inner">
                    <div class="page-title">
                        <h2>Others</h2>
                    </div>
                    <ol class="breadcrumb">
                        <li><a href="index.html">Home</a></li>
                        <li class="active">Ruchika Sen</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>


    {{-- ===========================================
                    PROFILE SECTION
    =========================================== --}}
    <section class="profile-section padding-tb">
        <div class="container">
            <div class="section-wrapper">
                <div class="member-profile">
                    <div class="profile-item">
                        <div class="profile-cover">
                            <img src="assets/images/profile/cover.jpg" alt="cover-pic" class="h-100">
                        </div>
                        <div class="profile-information">
                            <div class="profile-pic">
                                <img src="assets/images/profile/Profile.jpg" alt="DP">
                            </div>
                            <div class="profile-name">
                                <h4>Ruchika Sen</h4>
                                <p>Active 02 Minutes Ago</p>
                            </div>
                            <ul class="profile-contact">
                                <li>
                                    <a>
                                        <div class="icon">
                                            <button class="like-btn"> <i class="fa-regular fa-heart text-theme"></i> </button>
                                        </div>
                                        <div class="text">
                                            <p>Like</p>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <div class="icon"><i class="icofont-envelope"></i></div>
                                        <div class="text">
                                            <p>Message</p>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a>
                                        <div class="icon-img">
                                            <img src="{{ asset('assets/images/icons/platinum.png') }}" alt="..." class="w-100 h-100">
                                        </div>
                                        <div class="text">
                                            <p>Platinum Member</p>
                                        </div>
                                    </a>
                                </li>
                            </ul>

                        </div>
                    </div>
                    <div class="profile-details">
                        <div class="tab-content" id="nav-tabContent">

                            <!-- Profile tab -->
                            <div class="tab-pane fade active show" id="profile">
                                <div>
                                    <div class="row">
                                        <div class="col-xl-8">
                                            <article>
                                                <div class="info-card mb-20">
                                                    <div class="info-card-title">
                                                        <h6>Base Info</h6>
                                                    </div>
                                                    <div class="info-card-content">
                                                        <ul class="info-list">
                                                            <li>
                                                                <p class="info-name">Name</p>
                                                                <p class="info-details">Ruchika Sen</p>
                                                            </li>
                                                            <li>
                                                                <p class="info-name">Username</p>
                                                                <p class="info-details">ruchika_sen</p>
                                                            </li>
                                                            <li>
                                                                <p class="info-name">E-Mail</p>
                                                                <p class="info-details">ruchika_sen@gmail.com</p>
                                                            </li>
                                                            <li>
                                                                <p class="info-name">I'm a</p>
                                                                <p class="info-details">Woman</p>
                                                            </li>
                                                            <li>
                                                                <p class="info-name">Loking for a</p>
                                                                <p class="info-details">Men</p>
                                                            </li>
                                                            <li>
                                                                <p class="info-name">Who has</p>
                                                                <p class="info-details">Single</p>
                                                            </li>
                                                            <li>
                                                                <p class="info-name">Age</p>
                                                                <p class="info-details">36</p>
                                                            </li>
                                                            <li>
                                                                <p class="info-name">Date of Birth</p>
                                                                <p class="info-details">27-02-1996</p>
                                                            </li>
                                                            <li>
                                                                <p class="info-name">Address</p>
                                                                <p class="info-details">Streop Rd, Peosur, Inphodux,
                                                                    USA.</p>
                                                            </li>
                                                        </ul>

                                                    </div>
                                                </div>
                                                <div class="info-card mb-20">
                                                    <div class="info-card-title">
                                                        <h6>Bio</h6>
                                                    </div>
                                                    <div class="info-card-content">
                                                        <p>Collaboratively innovate compelling mindshare after
                                                            prospective partnerships Competently sereiz long-term
                                                            high-impact internal or "organic" sources via user friendly
                                                            strategic themesr areas creat Dramatically coordinate
                                                            premium partnerships.</p>
                                                    </div>
                                                </div>
                                                <div class="info-card mb-20">
                                                    <div class="info-card-title">
                                                        <h6>Summary</h6>
                                                    </div>
                                                    <div class="info-card-content">
                                                        <p>Collaboratively innovate compelling mindshare after
                                                            prospective partnerships Competently sereiz long-term
                                                            high-impact internal or "organic" sources via user friendly
                                                            strategic themesr areas creat Dramatically coordinate
                                                            premium partnerships rather than standards compliant
                                                            technologies ernd Dramatically matrix ethical collaboration
                                                            and idea-sharing through opensource methodologies and
                                                            Intrinsicly grow collaborative platforms vis-a-vis effective
                                                            scenarios. Energistically strategize cost effective ideas
                                                            before the worke unde.</p>
                                                    </div>
                                                </div>
                                                <div class="info-card">
                                                    <div class="info-card-title">
                                                        <h6>Physical info</h6>
                                                    </div>
                                                    <div class="info-card-content">
                                                        <ul class="info-list">
                                                            <li>
                                                                <p class="info-name">Height</p>
                                                                <p class="info-details">140cm</p>
                                                            </li>
                                                            <li>
                                                                <p class="info-name">Body Type</p>
                                                                <p class="info-details">Slim</p>
                                                            </li>
                                                            <li>
                                                                <p class="info-name">Ethnicity</p>
                                                                <p class="info-details">Asian</p>
                                                            </li>
                                                            <li>
                                                                <p class="info-name">Education</p>
                                                                <p class="info-details">Graduation</p>
                                                            </li>
                                                            <li>
                                                                <p class="info-name">Relationship</p>
                                                                <p class="info-details">Single</p>
                                                            </li>
                                                            <li>
                                                                <p class="info-name">Children</p>
                                                                <p class="info-details">No</p>
                                                            </li>
                                                            <li>
                                                                <p class="info-name">Smoke</p>
                                                                <p class="info-details">Light Smoker</p>
                                                            </li>
                                                            <li>
                                                                <p class="info-name">Drink</p>
                                                                <p class="info-details">Social Drinker</p>
                                                            </li>
                                                        </ul>

                                                    </div>
                                                </div>
                                            </article>
                                        </div>

                                        <!-- Aside Part -->
                                        <div class="col-xl-4">
                                            <aside class="mt-5 mt-xl-0">
                                                <div class="widget tab-widget">
                                                    <div class="widget-inner">
                                                        <div class="widget-title">
                                                            <h5>Ruchika Sen</h5>
                                                        </div>
                                                        <div class="widget-content">
                                                            <ul class="list-unstyled">
                                                                <li class="tab-item member">
                                                                    <span class="tab-head"> <i class="fa-regular fa-clock"></i> Member Since</span>
                                                                    29-11-2022
                                                                </li>
                                                                <li class="tab-item">
                                                                    <a href="#">
                                                                        {{--  <i class="fa-solid fa-circle-question"></i>  --}}
                                                                        <i class="fa-solid fa-circle-check text-success"  data-bs-toggle="tooltip" title="Trusted"></i>
                                                                        <span> Verified </span>
                                                                    </a>
                                                                </li>
                                                                <li class="tab-item">
                                                                    <a href="#">
                                                                        <i class="fa-brands fa-facebook"></i>
                                                                        Facebook
                                                                    </a>
                                                                </li>
                                                                <li class="tab-item">
                                                                    <a href="#">
                                                                        <i class="fa-brands fa-instagram"></i>
                                                                        Instagram
                                                                    </a>
                                                                </li>
                                                                <li class="tab-item">
                                                                    <a href="#">
                                                                        <i class="fa-brands fa-linkedin"></i>
                                                                        Linked In
                                                                    </a>
                                                                </li>
                                                                <li class="tab-item">
                                                                    <a href="#" class="member">
                                                                        <span class="tab-head text-danger"> Block User </span>
                                                                        <i class="fa-solid fa-chevron-right text-danger"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="tab-item">
                                                                    <a href="#" class="member">
                                                                        <span class="tab-head text-danger"> Report User </span>
                                                                        <i class="fa-solid fa-chevron-right text-danger"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="tab-item">
                                                                    <a href="#" class="member">
                                                                        <span class="tab-head text-danger"> Hide Profile </span>
                                                                        <i class="fa-solid fa-chevron-right text-danger"></i>
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                                {{--  <div class="widget search-widget">
                                                    <div class="widget-inner">
                                                        <div class="widget-title">
                                                            <h5>Filter Search Member</h5>
                                                        </div>
                                                        <div class="widget-content">
                                                            <p>Serious Dating With Options. Your Perfect
                                                                Match is Just a Click Away.</p>
                                                            <form action="" class="banner-form">
                                                                <div class="gender">
                                                                    <div class="custom-select right w-100">
                                                                        <select class="">
                                                                            <option value="0">I am a </option>
                                                                            <option value="1">Male</option>
                                                                            <option value="2">Female</option>
                                                                            <option value="3">Others</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="person">
                                                                    <div class="custom-select right w-100">
                                                                        <select class="">
                                                                            <option value="0">Looking for</option>
                                                                            <option value="1">Male</option>
                                                                            <option value="2">Female</option>
                                                                            <option value="3">Others</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="age">
                                                                    <div
                                                                        class="right d-flex justify-content-between w-100">
                                                                        <div class="custom-select">
                                                                            <select>
                                                                                <option value="1">18</option>
                                                                                <option value="2">19</option>
                                                                                <option value="3">20</option>
                                                                                <option value="4">21</option>
                                                                                <option value="5">22</option>
                                                                                <option value="6">23</option>
                                                                                <option value="7">24</option>
                                                                                <option value="8">25</option>
                                                                                <option value="9">26</option>
                                                                                <option value="10">27</option>
                                                                                <option value="11">28</option>
                                                                                <option value="13">29</option>
                                                                                <option value="14">30</option>
                                                                            </select>
                                                                        </div>

                                                                        <div class="custom-select">
                                                                            <select>
                                                                                <option value="1">36</option>
                                                                                <option value="2">19</option>
                                                                                <option value="3">20</option>
                                                                                <option value="4">21</option>
                                                                                <option value="5">22</option>
                                                                                <option value="6">23</option>
                                                                                <option value="7">24</option>
                                                                                <option value="8">25</option>
                                                                                <option value="9">26</option>
                                                                                <option value="10">27</option>
                                                                                <option value="11">28</option>
                                                                                <option value="13">29</option>
                                                                                <option value="14">30</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="city">
                                                                    <div class="custom-select right w-100">
                                                                        <select class="">
                                                                            <option value="0">Choose Your Country
                                                                            </option>
                                                                            <option value="1">USA</option>
                                                                            <option value="2">UK</option>
                                                                            <option value="3">Spain</option>
                                                                            <option value="4">Brazil</option>
                                                                            <option value="5">France</option>
                                                                            <option value="6">Newzeland</option>
                                                                            <option value="7">Australia</option>
                                                                            <option value="8">Bangladesh</option>
                                                                            <option value="9">Turki</option>
                                                                            <option value="10">Chine</option>
                                                                            <option value="11">India</option>
                                                                            <option value="12">Canada</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="interest">
                                                                    <div class="custom-select right w-100">
                                                                        <select class="">
                                                                            <option value="0">Your Interests
                                                                            </option>
                                                                            <option value="1">Gaming</option>
                                                                            <option value="2">Fishing</option>
                                                                            <option value="3">Skydriving</option>
                                                                            <option value="4">Swimming</option>
                                                                            <option value="5">Racing</option>
                                                                            <option value="6">Hangout</option>
                                                                            <option value="7">Tranvelling</option>
                                                                            <option value="8">Camping</option>
                                                                            <option value="9">Touring</option>
                                                                            <option value="10">Acting</option>
                                                                            <option value="11">Dancing</option>
                                                                            <option value="12">Singing</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <button class="">Find Your Partner</button>

                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>  --}}
                                                <div class="widget like-member">
                                                    <div class="widget-inner">
                                                        <div class="widget-title">
                                                            <h5>Recommended</h5>
                                                        </div>
                                                        <div class="widget-content">
                                                            <div class="row row-cols-3 row-cols-sm-auto g-3">
                                                                <div class="col">
                                                                    <div class="image-thumb">
                                                                        <a href="assets/images/widget/01.jpg" data-rel="lightcase">
                                                                            <img src="assets/images/widget/01.jpg" alt="img">
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="col">
                                                                    <div class="image-thumb">
                                                                        <a href="assets/images/widget/02.jpg" data-rel="lightcase">
                                                                            <img src="assets/images/widget/02.jpg" alt="img">
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="col">
                                                                    <div class="image-thumb">
                                                                        <a href="assets/images/widget/03.jpg" data-rel="lightcase">
                                                                            <img src="assets/images/widget/03.jpg" alt="img">
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="col">
                                                                    <div class="image-thumb">
                                                                        <a href="assets/images/widget/04.jpg" data-rel="lightcase">
                                                                            <img src="assets/images/widget/04.jpg" alt="img">
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="col">
                                                                    <div class="image-thumb">
                                                                        <a href="assets/images/widget/05.jpg" data-rel="lightcase">
                                                                            <img src="assets/images/widget/05.jpg" alt="img">
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="col">
                                                                    <div class="image-thumb">
                                                                        <a href="assets/images/widget/06.jpg" data-rel="lightcase">
                                                                            <img src="assets/images/widget/06.jpg" alt="img">
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="col">
                                                                    <div class="image-thumb">
                                                                        <a href="assets/images/widget/07.jpg" data-rel="lightcase">
                                                                            <img src="assets/images/widget/07.jpg" alt="img">
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="col">
                                                                    <div class="image-thumb">
                                                                        <a href="assets/images/widget/08.jpg" data-rel="lightcase">
                                                                            <img src="assets/images/widget/08.jpg" alt="img">
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="col">
                                                                    <div class="image-thumb">
                                                                        <a href="assets/images/widget/09.jpg" data-rel="lightcase">
                                                                            <img src="assets/images/widget/09.jpg" alt="img">
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </aside>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


@endsection
