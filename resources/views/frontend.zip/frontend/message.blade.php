@extends('frontend.layout.main-after')
@section('main2.container')


    {{-- ===========================================
                    PAGE HEADER
    =========================================== --}}
    <section class="page-header-section style-1 breadcrumb-section">
        <div class="container">
            <div class="page-header-content">
                <div class="page-header-inner">
                    <div class="page-title">
                        <h2>Messages</h2>
                    </div>
                    <ol class="breadcrumb">
                        <li><a href="profile">Home</a></li>
                        <li class="active">Messages</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    {{-- ===========================================
                    MESSAGES SECTION
    =========================================== --}}
    <section class="message-section container-fluid">
        <div>
            <div class="row">
                <div class="col-lg-3 col-md-4">
                    {{--  <div class="chat-inbox">

                        <form action="#">
                            <div class="search-bar">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                      <span class="input-group-text d-flow-root h-100 search-icon">
                                            <i class="fa-solid fa-magnifying-glass"></i>
                                      </span>
                                    </div>
                                    <input type="text" class="form-control" placeholder="Search">
                                </div>
                            </div>
                        </form>

                        <hr>

                        <div class="chat-item">
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/01.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Harry Porter
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/02.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Shaktiman
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/03.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Junior G
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/04.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Emma Watson
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/01.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Ronald Weisley
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/02.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Jack Smith
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/03.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Pinnochio
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/04.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Monica Ward
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>  --}}
                    <div class="message-tab">
                        <div class="message-link" id="inbox-tab">Inbox</div>
                        <div class="message-link" id="sent-tab">Sent</div>
                        <div class="message-link" id="archieve-tab">Archieve</div>
                        <div class="message-link" id="filtered-tab">Filtered Out</div>
                    </div>
                </div>
                <div class="col-lg-9 col-md-8 chat-box">

                    {{--  MESSAGE CHAT BOX  --}}
                    <div class="chat-main">
                        <div class="chat-head d-flex justify-content-between">
                            <div class="d-flex">
                                <div class="back-btn">
                                    <i class="fa-solid fa-arrow-left-long"></i>
                                </div>
                                <div class="person-img">
                                    <a href="other-profile">
                                        <img src="{{ asset('assets/images/profile/01.jpg') }}" alt="..." class="w-100 h-100">
                                    </a>
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name m-auto">
                                            Harry Porter
                                        </div>
                                        <div class="person-status d-flex">
                                            <span><i class="fa-solid fa-circle text-success"></i></span> Online
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="dropdown">
                                <button  type="button" data-toggle="dropdown">
                                    <i class="fa-solid fa-ellipsis-vertical"></i>
                                </button>
                                <ul class="dropdown-menu">
                                  <li><a href="#">Archieve Conversation</a></li>
                                  <li><a href="#">Delete Conversation</a></li>
                                  <li><a href="#">Block User</a></li>
                                  <li><a href="#">Hide User</a></li>
                                  <li><a href="#">Report User</a></li>
                                </ul>
                              </div>
                        </div>

                        <div class="chat-message">

                            <div class="chats">
                                <div class="messages">
                                    <div class="my-message">
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis, eius.</p>
                                    </div>
                                </div>

                                <div class="messages">
                                    <div class="other-message">
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis, eius.</p>
                                    </div>
                                </div>

                                <div class="messages">
                                    <div class="my-message">
                                        <p>Lorem ipsum dolor sit.</p>
                                    </div>
                                </div>

                                <div class="messages">
                                    <div class="other-message">
                                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    </div>
                                </div>

                                <div class="messages">
                                    <div class="my-message">
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis, eius.Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis, eius.</p>
                                    </div>
                                </div>

                                <div class="messages">
                                    <div class="other-message">
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis, eius.Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis, eius.</p>
                                    </div>
                                </div>
                                <div class="messages">
                                    <div class="my-message">
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis, eius.</p>
                                    </div>
                                </div>

                                <div class="messages">
                                    <div class="other-message">
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis, eius.</p>
                                    </div>
                                </div>

                                <div class="messages">
                                    <div class="my-message">
                                        <p>Lorem ipsum dolor sit.</p>
                                    </div>
                                </div>

                                <div class="messages">
                                    <div class="other-message">
                                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                                    </div>
                                </div>

                                <div class="messages">
                                    <div class="my-message">
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis, eius.Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis, eius.</p>
                                    </div>
                                </div>

                                <div class="messages">
                                    <div class="other-message">
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis, eius.Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis, eius.</p>
                                    </div>
                                </div>
                            </div>

                        </div>


                        <div class="chat-foot">
                            <div class="input-file h-100">
                                <label class="file-btn h-100" for="msgfile">
                                    <span class="mr-0"><i class="fa-solid fa-paperclip"></i></span>
                                </label>
                                <input type="file" name="messageFile" id="msgfile" class="d-none">
                            </div>
                            <div class="input-message h-100 flex-fill">
                                <input type="text" name="message" placeholder="Message...">
                            </div>
                            <div class="send-message h-100">
                                <button>
                                    <span><i class="fa-regular fa-paper-plane text-theme"></i></span>
                                </button>
                            </div>
                        </div>

                    </div>

                    {{--  PERSON LIST  --}}
                    <div class="chat-inbox" id="inbox">

                        <div class="chat-inbox-head">
                            <div class="inbox-head">
                                Inbox Messages
                            </div>
                            <div class="inbox-filters">
                                <div class="inbox-checkbox">
                                    <label for="unread">
                                        <input type="checkbox" name="unread"> Show Unread Only
                                    </label>
                                </div>
                                <div class="inbox-filter-btn">
                                    <button data-toggle="modal" data-target="#inbox-filter">
                                        <i class="fa-solid fa-sliders"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <form action="#">
                            <div class="search-bar">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                      <span class="input-group-text d-flow-root h-100 search-icon">
                                            <i class="fa-solid fa-magnifying-glass"></i>
                                      </span>
                                    </div>
                                    <input type="text" class="form-control" placeholder="Search">
                                </div>
                            </div>
                        </form>

                        <hr>

                        <div class="chat-item">
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/01.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Harry Porter
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/02.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Shaktiman
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/03.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Junior G
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/04.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Emma Watson
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/01.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Ronald Weisley
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/02.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Jack Smith
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/03.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Pinnochio
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/04.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Monica Ward
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/01.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Ronald Weisley
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/02.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Jack Smith
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/03.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Pinnochio
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/04.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Monica Ward
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="chat-inbox" id="sent">

                        <div class="chat-inbox-head">
                            <div class="inbox-head">
                                Sent Messages
                            </div>
                            <div class="inbox-filters">
                                <div class="inbox-checkbox">
                                    <label for="unread">
                                        <input type="checkbox" name="unread"> Show Unread Only
                                    </label>
                                </div>
                            </div>
                        </div>

                        <form action="#">
                            <div class="search-bar">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                      <span class="input-group-text d-flow-root h-100 search-icon">
                                            <i class="fa-solid fa-magnifying-glass"></i>
                                      </span>
                                    </div>
                                    <input type="text" class="form-control" placeholder="Search">
                                </div>
                            </div>
                        </form>

                        <hr>

                        <div class="chat-item">
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/01.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Harry Porter
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/02.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Shaktiman
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/03.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Junior G
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/04.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Emma Watson
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/01.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Ronald Weisley
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/02.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Jack Smith
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/03.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Pinnochio
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/04.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Monica Ward
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/01.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Ronald Weisley
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/02.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Jack Smith
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/03.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Pinnochio
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/04.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Monica Ward
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="chat-inbox" id="archieve">

                        <div class="chat-inbox-head">
                            <div class="inbox-head">
                                Archieve Messages
                            </div>
                            <div class="inbox-filters">
                                <div class="inbox-checkbox">
                                    <label for="unread">
                                        <input type="checkbox" name="unread"> Show Unread Only
                                    </label>
                                </div>
                            </div>
                        </div>

                        <form action="#">
                            <div class="search-bar">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                      <span class="input-group-text d-flow-root h-100 search-icon">
                                            <i class="fa-solid fa-magnifying-glass"></i>
                                      </span>
                                    </div>
                                    <input type="text" class="form-control" placeholder="Search">
                                </div>
                            </div>
                        </form>

                        <hr>

                        <div class="chat-item">
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/01.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Harry Porter
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/02.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Shaktiman
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/03.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Junior G
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/04.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Emma Watson
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="chat-inbox" id="filtered">

                        <div class="chat-inbox-head">
                            <div class="inbox-head">
                                Filtered Messages
                            </div>
                            <div class="inbox-filters">
                                <div class="inbox-checkbox">
                                    <label for="unread">
                                        <input type="checkbox" name="unread"> Show Unread Only
                                    </label>
                                </div>
                                <div class="inbox-filter-btn">
                                    <button data-toggle="modal" data-target="#inbox-filter">
                                        <i class="fa-solid fa-sliders"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <form action="#">
                            <div class="search-bar">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                      <span class="input-group-text d-flow-root h-100 search-icon">
                                            <i class="fa-solid fa-magnifying-glass"></i>
                                      </span>
                                    </div>
                                    <input type="text" class="form-control" placeholder="Search">
                                </div>
                            </div>
                        </form>

                        <hr>

                        <div class="chat-item">
                            <div class="empty-content">
                                <h4>No messages have been filtered out yet.</h4>
                                <p>If you haven't configured your settings yet, you can click the filter
                                    icon in the top-right corner, or click the button below.</p>
                            </div>
                            {{--  <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/01.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Harry Porter
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="person d-flex">
                                <div class="person-img">
                                    <img src="{{ asset('assets/images/profile/02.jpg') }}" alt="..." class="w-100 h-100">
                                </div>
                                <div class="person-detail flex-fill">
                                    <div class="d-flex flex-column h-100">
                                        <div class="person-name">
                                            Shaktiman
                                        </div>
                                        <div class="person-status">
                                            Hi, How are you ?
                                        </div>
                                    </div>
                                </div>
                            </div>  --}}
                        </div>

                    </div>

                    <div class="modal" id="inbox-filter">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Inbox Filters</h4>
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>
                            <div class="modal-body">
                                <p>
                                    The filters you set below will be applied to any new messages you receive.
                                    Messages already in your inbox will not be affected.
                                </p>
                                <div class="filter-container">
                                    <div class="dropdown">
                                        <button type="button"  data-toggle="dropdown">
                                          Verifications <i class="fa-solid fa-angle-down"></i>
                                        </button>
                                          <label for="verification"  class="dropdown-menu dropdown-menu-right">
                                            <ul>
                                                <li><input type="checkbox" name="verification" value="id-verify"> ID Verified</li>
                                                <li><input type="checkbox" name="verification" value="photo-verify">Photos Verified</li>
                                                <li><input type="checkbox" name="verification" value="Facebook">Facebook</li>
                                                <li><input type="checkbox" name="verification" value="Instagram">Instagram</li>
                                                <li><input type="checkbox" name="verification" value="LinkedIn">LinkedIn</li>
                                            </ul>
                                          </label>
                                    </div>
                                    <div class="dropdown">
                                        <button type="button" data-toggle="dropdown">
                                          Body Type <i class="fa-solid fa-angle-down"></i>
                                        </button>
                                          <label for="body"  class="dropdown-menu dropdown-menu-right">
                                            <ul>
                                                <li><input type="checkbox" name="body" value="Slim"> Slim</li>
                                                <li><input type="checkbox" name="body" value="Athletic">Athletic</li>
                                                <li><input type="checkbox" name="body" value="Average">Average</li>
                                                <li><input type="checkbox" name="body" value="Curvy">Curvy</li>
                                                <li><input type="checkbox" name="body" value="Overweight">Overweight</li>
                                            </ul>
                                          </label>
                                    </div>
                                    <div class="dropdown">
                                        <button type="button" data-toggle="dropdown">
                                          Ethnicity <i class="fa-solid fa-angle-down"></i>
                                        </button>
                                          <label for="body"  class="dropdown-menu dropdown-menu-right">
                                            <ul>
                                                <li><input type="checkbox" name="ethnicity" value="Asian"> Asian</li>
                                                <li><input type="checkbox" name="ethnicity" value="African">African</li>
                                                <li><input type="checkbox" name="ethnicity" value="East-Indian">East Indian</li>
                                                <li><input type="checkbox" name="ethnicity" value="Middle-Eastern">Middle Eastern</li>
                                                <li><input type="checkbox" name="ethnicity" value="Asian"> Asian</li>
                                                <li><input type="checkbox" name="ethnicity" value="African">African</li>
                                                <li><input type="checkbox" name="ethnicity" value="East-Indian">East Indian</li>
                                                <li><input type="checkbox" name="ethnicity" value="Middle-Eastern">Middle Eastern</li>
                                            </ul>
                                          </label>
                                    </div>
                                    <div class="dropdown">
                                        <button type="button" data-toggle="dropdown">
                                          Education <i class="fa-solid fa-angle-down"></i>
                                        </button>
                                          <label for="body"  class="dropdown-menu dropdown-menu-right">
                                            <ul>
                                                <li><input type="checkbox" name="education" value="High-School"> High School</li>
                                                <li><input type="checkbox" name="education" value="Intermediate">Intermediate</li>
                                                <li><input type="checkbox" name="education" value="Bachelor-Degree">Bachelor Degree</li>
                                                <li><input type="checkbox" name="education" value="Graduate-Degree">Graduate Degree</li>
                                                <li><input type="checkbox" name="education" value="PhD"> PhD</li>
                                                <li><input type="checkbox" name="education" value="African">African</li>
                                                <li><input type="checkbox" name="education" value="East Indian">East Indian</li>
                                                <li><input type="checkbox" name="education" value="Middle Eastern">Middle Eastern</li>
                                            </ul>
                                          </label>
                                    </div>
                                    <div class="dropdown">
                                        <button type="button" data-toggle="dropdown">
                                            Relationship <i class="fa-solid fa-angle-down"></i>
                                        </button>
                                          <label for="body"  class="dropdown-menu dropdown-menu-right">
                                            <ul>
                                                <li><input type="checkbox" name="body" value="Single"> Single</li>
                                                <li><input type="checkbox" name="body" value="Married">Married</li>
                                                <li><input type="checkbox" name="body" value="Open-Relationship">Open Relationship</li>
                                                <li><input type="checkbox" name="body" value="Divorced">Divorced</li>
                                                <li><input type="checkbox" name="body" value="Widowed">Widowed</li>
                                            </ul>
                                          </label>
                                    </div>
                                    <div class="dropdown">
                                        <button type="button" data-toggle="dropdown">
                                            Children <i class="fa-solid fa-angle-down"></i>
                                        </button>
                                          <label for="body"  class="dropdown-menu dropdown-menu-right">
                                            <ul>
                                                <li><input type="checkbox" name="body" value="Yes"> Yes</li>
                                                <li><input type="checkbox" name="body" value="No">No</li>
                                            </ul>
                                          </label>
                                    </div>
                                    <div class="dropdown">
                                        <button type="button" data-toggle="dropdown">
                                            Smoke <i class="fa-solid fa-angle-down"></i>
                                        </button>
                                          <label for="body"  class="dropdown-menu dropdown-menu-right">
                                            <ul>
                                                <li><input type="checkbox" name="body" value="Non-Smoker">Non Smoker</li>
                                                <li><input type="checkbox" name="body" value="Light-Smoker">Light Smoker</li>
                                                <li><input type="checkbox" name="body" value="Heavy-Smoker">Heavy Smoker</li>
                                            </ul>
                                          </label>
                                    </div>
                                    <div class="dropdown">
                                        <button type="button" data-toggle="dropdown">
                                            Drink <i class="fa-solid fa-angle-down"></i>
                                        </button>
                                          <label for="body"  class="dropdown-menu dropdown-menu-right">
                                            <ul>
                                                <li><input type="checkbox" name="body" value="Non-Drinker"> Non Drinker</li>
                                                <li><input type="checkbox" name="body" value="Social-Drinker">Social Drinker</li>
                                                <li><input type="checkbox" name="body" value="Heavy-Drinker">Heavy Drinker</li>
                                            </ul>
                                          </label>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-danger" data-dismiss="modal">Search</button>
                            </div>
                          </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>



@endsection
